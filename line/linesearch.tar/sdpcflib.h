#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <float.h>
#include <math.h>
#include <time.h>

typedef struct {
  double *s;
  double *y;
  double rho;
  double a;
} lbfgsvec;

typedef struct {
  int     n;
  int     m;
  double  muw;
  double  muy;
  double  pureval;
  double* b;
  double* e;
  int*    i;
  int*    r;
  int*    s;
  double* wt;
  char*   sign;
  int     nnz_indiv;
  int*    perm;
  int*    invp;
  int     nnz_S;
  int*    Scolptr;
  int*    Scolind;
  double* Scolval;
  double* Xcolval;
  double* z;
  int*    Lcolptr;
  int*    Lcolind;
  double* Lcolval;
  int*    Lrowtocol;
  int*    Lcoltorow;
  int*    Lrowptr;
  int*    Lrowind;
  double* Lrowval;
  int     nnz_L;
  int*    inS;
  int     maxiter;
  int     timelimit;
  double  initmu;
  double  finalmu;
  double  mufac;
  int     M;
  int     freqprint;
  int     reorder;
  int     scaling;
  int     general;
} problemdata;

int sdpcf(int, int, int, double*, double*, char*, int*, int*, int*, double*, int, int, double, double, double, int, int, int, int, int);
int function(problemdata*, double*, double*);
int cholesky(problemdata*, double*);
int gradient(problemdata*, double*, double*);
int computeX(problemdata*, double*);
int WP_linesearch(problemdata*, double*, double*, double*, double*, double*, double*, double, double, int, double);
int bracketing(problemdata*, double*, double*, double*, double*, double*, double*, double, double, int, double, double, double, double, double, double, double);
int sectioning(problemdata*, double*, double*, double*, double*, double*, double*, double, double, int, double, double, double, double, double, double, double, double, double, double);
int quadratic_interpolation(double, double, double, double, double, double, double, double*);
int addvectovec(double*, double*, int);
int addscaledvectovec(double*, double, double*, int);
int copyvectovec(double*, double*, int);
int copyscaledvectovec(double*, double, double*, int);
double dotproduct(double*, double*, int);
double doublemin(double, double);
double doublemax(double, double);
double infnorm(double*, int);
int move_in_dir(double*, double*, double, double*, int);
int scalevec(double, double*, int);
int zerovec(double*, int);
int dirlbfgs(lbfgsvec*, double*, double*, int, int, int);
int updatelbfgs1(lbfgsvec*, double*, int, int);
int updatelbfgs2(lbfgsvec*, double*, double*, double, int*, int, int);
int initialize(problemdata**, double**, double**, double**, double**, lbfgsvec**, int, int, int, double*, double*, char*, int*, int*, int*, double*, int, int, double, double, double, int, int, int, int, int);
int symbfactor(problemdata*, int*, int*, int*);
int smbfct(int, int*, int *, int*, int*, int*, int*, int*, int*, int*, int*, int*, int*);
int quicksort3(int*, int*, int*, double*, int, int);
int partition3(int*, int*, int*, double*, int, int);
int shutdown(problemdata*, double*, double*, double*, double*, lbfgsvec*);

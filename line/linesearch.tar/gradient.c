#include "sdpcflib.h"

int gradient(problemdata* data, double* g, double* x)
{
  int i, k, n, m, r, s, nnz_indiv;
  int *Scolptr, *Scolind, *inS, *Lcolptr;
  double *y, *gy, *gw, *e, *w;
  double *Scolval, *Xcolval, *Lcolval;

  n = data->n; m = data->m; nnz_indiv = data->nnz_indiv;
  Scolptr = data->Scolptr;
  Scolind = data->Scolind;
  Scolval = data->Scolval;
  inS = data->inS;
  Lcolptr = data->Lcolptr;
  Xcolval = data->Xcolval;
  Lcolval = data->Lcolval;
  e = data->e;
  y = x; w = x+m;
  gy = g; gw = g+m;

  /* We now actually compute X. */
  computeX(data, x);

  /* Now that X has been computed, we must compute 2*diag(XL)
     and b - A(X). We do 2*diag(XL) first, which is a rather
     easy computation since both X and L have the same data
     structure. */
    
  /* We compute each diagonal element. */
    
  for(i = 1; i <= n; i++) {
    
    gw[i] = e[i]*w[i];
    
    /* Now multiply row i of X with column i of L (lower part
       only). This is the same as mulitplying column i of X
       with column i of L. Add to gw[i]. */
     
    for(k = Lcolptr[i]; k <= Lcolptr[i+1]-1; k++)
      gw[i] += Xcolval[k]*Lcolval[k];
      
    /* Multiply by 2. */
      
    gw[i] *= 2.0;

  }

  /* We now turn to the computation of b - A(X). */

  copyvectovec(gy, data->b, m);
  for(k = 1; k <= nnz_indiv; k++) {
    i = data->i[k]; r = data->r[k]; s = data->s[k];
    if(i > 0) {
      if(r != s) gy[i] -= 2.0*data->wt[k]*Xcolval[inS[k]];
      else gy[i] -= data->wt[k]*e[r];
      /* Note that inS actually gives index "inL" and that inL has been destroyed. */
    }
  }

  for(i = 1; i <= m; i++) if(data->sign[i] != 'f') gy[i] -= data->muy/y[i];
  for(i = 1; i <= n; i++) gw[i] -= 2.0*data->muw/w[i];

  return 1;
}

/* This needs more documentation. */

int computeX(problemdata* data, double* x)
{
  int i, j, k, n, m, nnz_L;
  int *Lrowptr, *Lrowind, *Lrowtocol;
  int *Lcolptr, *Lcolind, *Lcoltorow;
  double *Lcolval, *Xcolval, *w;
  double *tempvec, tempval;

  n = data->n; m = data->m; nnz_L = data->nnz_L;
  w = x+m;
  Lrowptr = data->Lrowptr; Lrowind = data->Lrowind; Lrowtocol = data->Lrowtocol;
  Lcolptr = data->Lcolptr; Lcolind = data->Lcolind; Lcoltorow = data->Lcoltorow;
  Lcolval = data->Lcolval;
  Xcolval = data->Xcolval;

  /* X has the exact same data structure as L but with a constant
     diagonal. So we only store the strictly lower part of X. */

  zerovec(Xcolval, nnz_L);

  /* Question: Where does the diagonal of X come into play? */

  tempvec = (double*)calloc(n+1, sizeof(double));
  copyvectovec(tempvec, data->e, n);

  for(j = 1; j <= n; j++) for(i = Lcolptr[j]; i <= Lcolptr[j+1]-1; i++)
    Xcolval[i] = -tempvec[Lcolind[i]]*Lcolval[i];
  for(k = n-2; k >= 1; k--) {
    zerovec(tempvec, n);
    for(i = Lcolptr[k+1]; i <= Lcolptr[k+2]-1; i++)
      tempvec[Lcolind[i]] = Xcolval[i];
    for(i = Lrowptr[k+1]; i <= Lrowptr[k+2]-1; i++)
      for(j = Lrowtocol[i]; j <= Lcolptr[Lrowind[i]+1]-1; j++) {
        tempval = tempvec[Lcolind[j]]/w[k+1];
        Xcolval[Lrowtocol[i]] -= Lcolval[j]*tempval;
        Xcolval[j] -= Lcolval[Lrowtocol[i]]*tempval;
      }
  }
  for(j = 1; j <= n; j++) for(i = Lcolptr[j]; i <= Lcolptr[j+1]-1; i++)
      Xcolval[i] /= w[j];



  free(tempvec);

  return 1;
}

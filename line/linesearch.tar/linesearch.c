#include "sdpcflib.h"

/* Correct function declarations -- copy and paste

int WP_linesearch(problemdata*, double*, double*, double*, double*, double*, double*, double, double, int, double);
int bracketing(problemdata*, double*, double*, double*, double*, double*, double*, double, double, int, double, double, double, double, double, double, double);
int sectioning(problemdata*, double*, double*, double*, double*, double*, double*, double, double, int, double, double, double, double, double, double, double, double, double, double);
int quadratic_interpolation(double, double, double, double, double, double, double, double*);

*/

/* Need access to util.c */
/* 
  Function to compute stepsize that minimizes the function f(x+alpha*d)  
  
  The algorithm is as given in Practical Optimization by R. Fletcher,
  page 33 through 39.
*/

int WP_linesearch(problemdata* data, double* newf, double* newpt, double* pt, double* stepsize, double* dir, double* grad, double f_zero, double df_zero, int dim, double ss_upbd)
{
  /* define parameters */
  
  double sigma = 0.1;                 /* Wolfe Powell parameter */
  double rho   = 0.01;                /* Goldstein parameter -- the smaller, the tighter */
  double tau1  = 9.0;                 /* preset factor for jump of alpha */
  double tau2  = 0.1;                 /* preset factor for alpha in sect. */
  double tau3  = 0.5;                 /* preset factor for alpha in sect. */ 
  double f_lower_bound = -1.0e20;     /* lower bound of objective function */

  return bracketing(data, newf, newpt, pt, stepsize, dir, grad, f_zero, df_zero, dim, ss_upbd, sigma, rho, tau1, tau2, tau3, f_lower_bound);
} 


/* function bracketing to get a bracket trial for alpha */

int bracketing(problemdata* data, double* newf, double* newpt, double* pt, double* stepsize, double* dir, double* grad, double f_zero, double df_zero, int dim, double ss_upbd, double sigma, double rho, double tau1, double tau2, double tau3, double f_lower_bound)
{
  double a;                     /* one value of ss bracket */
  double b;                     /* another value of ss bracket */
  double a1;                    /* lower limit of updated ss */
  double b1;                    /* upper limit of updated ss */ 
  double localmu;               /* upper bound of initial guess for ss */
  double f_a;                   /* function value at ss=a */
  double df_a;                  /* derivative of function at ss=a */
  double f_b;                   /* function at ss=b */
  double df_b;                  /* derivative of function at ss=b */
  double ss_prev = 0.0;         /* previous value of ss, initially 0 */
  double f_ss_prev;
  double df_ss_prev;
  double f_ss;
  double df_ss;
  int k = 1;
  double tempval, ss;

   f_ss_prev =  f_zero;
  df_ss_prev = df_zero;

  /* if(ss_upbd > 0) localmu = ss_upbd; */
  localmu = (f_lower_bound - f_zero)/(rho*df_zero);

  ss = ss_upbd;
 
  for(k = 1; k <= 100; k++) {
    move_in_dir(newpt, pt, ss, dir, dim);
    function(data, &f_ss, newpt);
    if(_isnan(f_ss)) f_ss = 1.0e20;
    if(f_ss <= f_lower_bound) { *stepsize = ss; *newf = f_ss; return 1; } /* This probably never occurs. */
    if(f_ss > f_zero + ss*rho*df_zero || f_ss >= f_ss_prev) {
      a = ss_prev; f_a = f_ss_prev; df_a = df_ss_prev;
      b = ss;      f_b = f_ss;
      *stepsize = ss;
      return sectioning(data, newf, newpt, pt, stepsize, dir, grad, f_zero, df_zero, dim, sigma, rho, tau2, tau3, a, b, f_a, f_b, df_a, 0.0);
    }
    gradient(data, grad, newpt);
    df_ss = dotproduct(grad, dir, dim);
    if(fabs(df_ss) <= -sigma*df_zero) { *stepsize = ss; *newf = f_ss; return 1; }
    if (df_ss >= 0.0) {
      a = ss;      f_a = f_ss;      df_a = df_ss;
      b = ss_prev; f_b = f_ss_prev; df_b = df_ss_prev;
      *stepsize = ss;
      return sectioning(data, newf, newpt, pt, stepsize, dir, grad, f_zero, df_zero, dim, sigma, rho, tau2, tau3, a, b, f_a, f_b, df_a, df_b);
    }
    if(localmu <= (2*ss - ss_prev)) {
      ss_prev = ss;
      f_ss_prev = f_ss;
      df_ss_prev = df_ss;
      ss = localmu;
    }
    else {
      /* Store value of ss before interpolation. */
      tempval = ss;
      /* Prepare for interpolation. */
      a = ss_prev; f_a = f_ss_prev; df_a = df_ss_prev;
      b = ss;     f_b = f_ss;      df_b = df_ss;
      a1 = 2*ss - ss_prev; 
      b1 = doublemin(localmu, ss + tau1*(ss - ss_prev));
      /* Do interpolation. */
      quadratic_interpolation(f_a, df_a, f_b, a, b, a1, b1, &ss);
      /* Prepare for next round. */
      ss_prev = tempval;
      f_ss_prev = f_ss;
      df_ss_prev = df_ss;
    }
  }

  *stepsize = ss; *newf = f_ss;
  printf("Line search failed (1).\n");
  return 0;

}


/* function to choose the section that gives the appropriate properties
   for alpha values */

int sectioning(problemdata* data, double* newf, double* newpt, double* pt, double* stepsize, double* dir, double* grad, double f_zero, double df_zero, int dim, double sigma, double rho, double tau2, double tau3, double a, double b, double f_a, double f_b, double df_a, double df_b)
{
  double a1;                 /* lower limit of ss bracket */
  double b1;                 /* upper limit of ss bracket */
  double f_ss;
  double df_ss;
  int k;
  double ss;

  ss = *stepsize;
  
  for(k = 1; k <= 99; k++) {
    if(k%100 == 0) {
      printf("k = %d\n", k);
    }
    a1 = a + tau2*(b - a);
    b1 = b - tau3*(b - a); 
    quadratic_interpolation(f_a, df_a, f_b, a, b, a1, b1, &ss);
    move_in_dir(newpt, pt, ss, dir, dim);
    function(data, &f_ss, newpt);
    if(_isnan(f_ss)) f_ss = 2*f_a;
    if(f_ss > f_zero + rho*ss*df_zero || f_ss >= f_a) {
      /* Prepare for next round. */
      a = a;  f_a = f_a;  df_a = df_a;
      b = ss; f_b = f_ss;
    }
    else {
      gradient(data, grad, newpt);
      df_ss = dotproduct(grad, dir, dim);
      if (fabs(df_ss) <= ((- sigma) * df_zero)) {
      /* if (df_ss <= ((- sigma) * df_zero)) { */
        *stepsize = ss;
        *newf = f_ss;
        return 1;
      }
      if((b - a)*df_ss >= 0.0) { b = a; f_b = f_a; df_b = df_a; }
      else                     { b = b; f_b = f_b; df_b = df_b; }
      a = ss; f_a = f_ss; df_a = df_ss;
    }
  }

  *stepsize = ss; *newf = f_ss;
  printf("Line search failed (2).\n");
  exit(0);
  return 0;
}


/* find minimizer c of quadratic function */

int quadratic_interpolation(double f_a, double df_a, double f_b, double a, double b, double a1, double b1, double* c) 
{
  double za1, zb1, root;
  double endptmin;

  za1 = f_a + df_a*(a1 - a) + (f_b - f_a - (b-a)*df_a)*(a1 - a)*(a1 - a)/((b - a)*(b - a));
  zb1 = f_a + df_a*(b1 - a) + (f_b - f_a - (b-a)*df_a)*(b1 - a)*(b1 - a)/((b - a)*(b - a));
  if(za1 < zb1) endptmin = a1;
  else endptmin = b1;
  root = a - (b-a)*(b-a)*df_a/(2*(f_b - f_a - (b-a)*df_a));

  if(f_b - f_a - (b-a)*df_a < 0) {       /* Opens downward. */
    if(a1 < b1) {
      if(a1 <= root && root <= b1) *c = endptmin;
      if(root < a1) *c = b1;
      if(root > b1) *c = a1;
    }
    else {
      if(b1 <= root && root <= a1) *c = endptmin;
      if(root < b1) *c = a1;
      if(root > a1) *c = b1;
    }
  }
  else {                                 /* Opens upward. */
    if(a1 < b1) {
      if(a1 <= root && root <= b1) *c = root;
      if(root < a1) *c = a1;
      if(root > b1) *c = b1;
    }
    else {
      if(b1 <= root && root <= a1) *c = root;
      if(root < b1) *c = b1;
      if(root > a1) *c = a1;
    }
  }

  return 1;

}

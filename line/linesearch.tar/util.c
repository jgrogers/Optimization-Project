/* correct function declarations -- copy and paste 

int addvectovec(double*, double*, int);
int addscaledvectovec(double*, double, double*, int);
int copyvectovec(double*, double*, int);
int copyscaledvectovec(double*, double, double*, int);
double dotproduct(double*, double*, int);
double doublemin(double, double);
double doublemax(double, double);
double infnorm(double*, int);
int intmin(int, int);
int intmax(int, int);
int move_in_dir(double*, double*, double, double*, int);
int scalevec(double, double*, int);
int zerovec(double*, int);

May need to include <math.h> for fabs() in infnorm. Yes.

*/

#include <math.h>

int addvectovec(double* vec1, double* vec2, int length)
{

  int i;

  for(i = 1; i <= length; i++) vec1[i] += vec2[i];

  return 1;
}

int addscaledvectovec(double* vec1, double scalar, double* vec2, int length)
{

  int i;

  for(i = 1; i <= length; i++) vec1[i] += scalar*vec2[i];

  return 1;
}


int copyvectovec(double* newvec, double* oldvec, int length)
{
  int i;

  for(i = 1; i <= length; i++) newvec[i] = oldvec[i];

  return 1;
}

int copyscaledvectovec(double* newvec, double scalar, double* oldvec, int length)
{
  int i;

  for(i = 1; i <= length; i++) newvec[i] = scalar*oldvec[i];

  return 1;
}

double dotproduct(double* vec1, double* vec2, int length)
{
  int i;
  double sum;

  if(length < 1) { return 0.0; }
  sum = 0.0;
  for(i = 1; i <= length; i++) sum += vec1[i]*vec2[i];

  return sum;
}

double doublemin(double a, double b)
{
  if(a < b) return a;
  else return b;
}

double doublemax(double a, double b)
{
  if(a > b) return a;
  else return b;
}


double infnorm(double* vec, int length)
{
  int i;
  double max = -1.0e20;

  for(i = 1; i <= length; i++)
    max = doublemax(max, fabs(vec[i]));

  return max;
}

int intmin(int a, int b)
{
  if(a < b) return a;
  else return b;
}

int intmax(int a, int b)
{
  if(a > b) return a;
  else return b;
}

int move_in_dir(double* new, double* old, double scalar, double* dir, int length)
{
  int i;

  for(i = 1; i <= length; i++)
    new[i] = old[i] + scalar*dir[i];

  return 1;
}

int scalevec(double scalar, double* vec, int length)
{
  int i;

  for(i = 1; i <= length; i++) vec[i] *= scalar;

  return 1;
}

int zerovec(double* vec, int length)
{
  int i;

  for(i = 1; i <= length; i++) vec[i] = 0.0;
 
  return 1;
}

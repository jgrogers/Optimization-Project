#include "sdpcflib.h"

int function(problemdata* data, double* fval, double* x)
{
  int i, r, s, k, n, m, nnz_indiv;
  int *Lrowptr;
  double *Lrowval;
  double *y, *w, *z, weight;
  double sumb, sume, logdet, logsum;

  n = data->n; m = data->m; nnz_indiv = data->nnz_indiv;
  Lrowptr = data->Lrowptr; Lrowval = data->Lrowval;
  y = x; w = x+m;
  z = data->z;

  for(i = 1; i <= n; i++) if(w[i] <= 0.0) {
    *fval = 1.0e20;
    return 1;
  }
  for(i = 1; i <= m; i++) {
    if((data->sign[i] == 'p' && y[i] <= 0.0) ||
      (data->sign[i] == 'n' && y[i] >= 0.0)) {
      *fval = 1.0e20;
      return 1;
    }
  }

  cholesky(data, x);

  /* The following procedure extracts diag(S) - diag(A^*(y) - C) into z. */
  /* Can be altered to save time, like in old sdpcf.c. */
  for(r = 1; r <= n; r++) z[r] = w[r]*w[r]; 
  for(k = 1; k <= nnz_indiv; k++) {
    i = data->i[k]; r = data->r[k]; s = data->s[k]; weight = data->wt[k];
    if(r == s) {
      if(i != 0) z[r] -= weight*y[i];
      else z[r] += weight;
    }
  }
  for(r = 1; r <= n; r++) for(s = Lrowptr[r]; s <= Lrowptr[r+1]-1; s++)
      z[r] += Lrowval[s]*Lrowval[s];

  sumb = dotproduct(data->b, y, m);
  sume = dotproduct(data->e, z, n);
  logdet = 1.0;
  for(i = 1; i <= n; i++) logdet *= w[i];
  logdet = 2.0*log(logdet);
  logsum = 0.0;
  for(i = 1; i <= m; i++) {
    if(data->sign[i] == 'p') logsum += log(y[i]);
    if(data->sign[i] == 'n') logsum += log(-y[i]);
  }
  *fval = sumb + sume - data->muw*logdet - data->muy*logsum;
  data->pureval = sumb + sume;
  if(!_finite(*fval)) *fval = 1.0e20;
  return 1;

}


int cholesky(problemdata* data, double* x)
{
  int i, j, k, n, m, r, nnz_indiv, col, index;
  int *Lrowptr, *Lrowind, *Lrowtocol;
  int *Lcolptr, *Lcolind, *Lcoltorow;
  double *Lcolval, *Lrowval, *y, *w;
  double weight, tempval, *tempvec;

  n = data->n; m = data->m; nnz_indiv = data->nnz_indiv;
  Lrowptr = data->Lrowptr; Lrowind = data->Lrowind; Lrowtocol = data->Lrowtocol;
  Lcolptr = data->Lcolptr; Lcolind = data->Lcolind; Lcoltorow = data->Lcoltorow;
  Lcolval = data->Lcolval; Lrowval = data->Lrowval;
  y = x; w = x+m;

  tempvec = (double*)calloc(n+1, sizeof(double)); /* It used to say n+2. Why? Lovasz? */
  index = 1;

  /* We now begin to fill up L. This is a rather difficult
     subroutine to understand, but I'm sure it's correct. */

  for(j = 1; j <= n; j++) {

    /* The full vector tempvec is where we will compute the
       j-th column of L. The i-th entry of tempvec (where i > j)
       stores the (i,j)-th entry of A^*(y) - C minus the dot product of
       the i-th row of L with the j-th row of L (but only the first
       j-1 entries), all divided by w_j = w[j]. */

    /* Therefore, tempvec is initialized with the j-th column of
       A^*(y) - C (only those entries having i > j). */

    /* When j = n, this contributes nothing to tempvec. */
    
    zerovec(tempvec+j, n-j);
    while(data->s[index] < j) index++;
    while(data->s[index] == j && index <= nnz_indiv) {
      i = data->i[index]; r = data->r[index]; weight = data->wt[index];
      if(r != j) {
        if(i != 0) tempvec[r] += weight*y[i];
        else tempvec[r] -= weight;
      }
      index++; 
    }

    /* Now we add into (subtract from?) tempvec the dot products of the i-th rows
       of L with the j-th row of L (but only the first j-1 entries). */

    /* The first loop with k passes through the j-th row of L. */

    for(k = Lrowptr[j]; k <= Lrowptr[j+1]-1; k++) {
    
      /* We store what column we are in during our pass through the
         j-th row in the variable col, and we store the entry of
         L in tempval. These will be used over and over again. */

      col = Lrowind[k]; tempval = Lrowval[k];

      /* We now use the rowtocol converter to jump to the same
         spot in the column representation of L. Recall that i > j.
         Hence, we multiply tempval by all the rows in the same
         column below our current entry. We store these multiplications
         in the appropriate entry of tempvec. */

      for(i = Lrowtocol[k]+1; i <= Lcolptr[col+1]-1; i++)
        tempvec[Lcolind[i]] -= tempval*Lcolval[i];
    }

    /* Finally, we divide by w[j]. */

    for(i = j+1; i <= n; i++) tempvec[i] /= w[j];
    
    /* tempvec now stores the information we need. Write into
       row and column representations of L. */

    for(i = Lcolptr[j]; i <= Lcolptr[j+1]-1; i++) 
      Lrowval[Lcoltorow[i]] = Lcolval[i] = tempvec[Lcolind[i]];

  }

  free(tempvec);

  return 1;
}